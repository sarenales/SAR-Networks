#!/usr/bin/env python3

from twisted.protocols.basic import LineReceiver
from twisted.internet.protocol import Factory
from twisted.internet import reactor

MAX_USERS = 100
MAX_MSG_LENGTH = 255
MAX_USER_LENGTH = 16
PORT = 8000

palabras_malsonantes = ["mongolo", "tonto", "idiota"]

class ChatProtocol(LineReceiver):
    def __init__(self, factory):
        self.factory = factory
        self.name = None
        self.timer=0;
        
                   
    def connectionMade(self):
        if len(self.factory.users) == MAX_USERS:
            self.sendLine(b"-1")
            self.transport.loseConnection()
        else:
            features = " ".join(self.factory.features.values()).encode("utf-8")
            self.sendLine(b"FTR" + features)

            userlist = " ".join(self.factory.users.keys()).encode("utf-8")
            self.sendLine(b"USR" + userlist)
            self.timer=reactor.callLater(10, self.notConnection)

    def connectionLost(self, reason):
        if self.name:
            del self.factory.users[self.name]
            self.broadcastMessage("OUT" + self.name)

    def lineReceived(self, line):
        line = line.decode("utf-8")
        self.timer.reset(10)
        if line.startswith("NME") and not self.name:
            name = line[3:]
            if " " in name:
                self.sendLine(b"-2")
            elif len(name) > MAX_USER_LENGTH:
                self.sendLine(b"-3")
            elif name in self.factory.users.keys():
                self.sendLine(b"-4")
            else:
                self.name = name
                self.factory.users[self.name] = self
                self.broadcastMessage("INN" + self.name)
                self.sendLine(b"+")
                
        elif line.startswith("MSG") and self.name:
            message = line[3:]
            if len(message) > MAX_MSG_LENGTH:
                self.sendLine(b"-5")
            else:
                for pal in palabras_malsonantes:
                   message = message.replace(pal, "#"*len(pal))

                message = "MSG{} {}".format(self.name, message)
                self.broadcastMessage(message)
                self.sendLine(b"+")
                
        elif line.startswith("WRT") and self.name:
            message = "WRT{}".format(self.name)
            self.broadcastMessage(message)
        
        else:
            self.sendLine(b"-0")

    def broadcastMessage(self, message):
        for protocol in self.factory.users.values():
            if protocol != self:
                protocol.sendLine(message.encode("utf-8"))
                
    def notConnection(self):
        self.sendLine(b'NOP')
        self.timer=reactor.callLater(10, self.notConnection)

class ChatFactory(Factory):
    def __init__(self):
        self.users = {}
        self.features = { 'FILES':'0' , 'CEN':'1', 'NOP':'1', 'SSL':'0' }

    def buildProtocol(self, addr):
        return ChatProtocol(self)

if __name__ == "__main__":
    reactor.listenTCP(PORT, ChatFactory())
    reactor.run()
