#!/usr/bin/env python3

import socket

PORT = 50007

"""A COMPLETAR POR EL/LA ESTUDIANTE:
Crear un socket y asignarle su direccion.
"""

while True:
	"""A COMPLETAR POR EL/LA ESTUDIANTE:
	Recibir un mensaje y responder con el mismo.
	"""
"""A COMPLETAR POR EL/LA ESTUDIANTE:
Cerrar socket.
"""
